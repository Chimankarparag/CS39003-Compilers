char roll[10], name[101];
unsigned short int yob;
float CGPA;
char gender;

long int a, *p, **q, ***r, A[5], B[6][7], **C[2][3][4];

double points[100][3], *P;

void *vptr;

unsigned char letters[26];

