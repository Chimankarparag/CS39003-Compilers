char letter, alphabet[26];
unsigned long int a, *p, **q, ***r, A[5], B[6][7], **C[2][3][4];
void *vptr;

struct stud {
   char roll[10];
   char name[101];
   short int yob;
   float CGPA;
   char gender;
} FooBar;

struct stud BTech[200], Dual[100], MTech[150], MS[100], PhD[250];

struct listnode {
   struct coordinates {
      int x, y, z;
   } point;
   struct listnode *next, *prev;
};

struct listnode *head, *tail;